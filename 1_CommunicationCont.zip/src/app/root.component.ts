import { Component, AfterViewInit, ViewChild, ViewChildren, QueryList } from "@angular/core";
import { CounterComponent } from "./counter/counter.component";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Communication</h1>
            </div>

            <div>
                <h2 class="alert alert-danger">{{message}}</h2>
                <counter (onMax)=maxedOut($event) #c1>
                    <h2>From Root</h2>
                </counter>
                <counter [interval]=10 #c2></counter>
                <br/>
                <div class="col-md-2">
                    <button class="btn btn-success btn-block" (click)=c1.reset()>Parent Reset 1</button>
                    <button class="btn btn-success btn-block" (click)=p_reset(c1)>Parent Reset 2</button>
                </div>
                <!-- <counter [interval]=10></counter> -->
            </div>
        </div>
    `
})
export class RootComponent implements AfterViewInit {

    flag: boolean;
    message: string;

    // @ViewChild(CounterComponent)
    // counter: CounterComponent;
    @ViewChild("c2")
    counter: CounterComponent;

    @ViewChildren(CounterComponent)
    qList: QueryList<CounterComponent>;

    constructor() {
        this.flag = true;
        this.message = "";
    }

    ngAfterViewInit(): void {
        // console.log("ngAfterViewInit", this.counter);
        this.counter.interval = 100;
        console.log(this.qList);
    }

    maxedOut(flag: boolean) {
        if (flag)
            this.message = "Max Click Reaced, click reset to continue...";
        else
            this.message = "";
    }

    p_reset(cArg: CounterComponent) {
        cArg.reset();
    }
}