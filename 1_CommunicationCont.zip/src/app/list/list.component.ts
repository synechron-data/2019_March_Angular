import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
    selector: 'list',
    templateUrl: 'list.component.html'
})

export class ListComponent implements OnInit {
    @Input() pList: Array<string>;
    @Output() onSelection: EventEmitter<string>;

    sPerson: string;

    constructor() { 
        this.onSelection = new EventEmitter<string>();
    }

    ngOnInit() { }

    select(p: string, e:Event) {
        this.sPerson = p;
        this.onSelection.emit(this.sPerson);
        e.preventDefault();
    }
}