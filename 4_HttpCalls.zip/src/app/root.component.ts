import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Post } from './models/post.model';
import { PostsService } from './services/posts.service';

@Component({
    selector: 'root',
    templateUrl: 'root.component.html',
    providers: [PostsService]
})

export class RootComponent implements OnInit {
    url: string;
    message: string;
    posts: Array<Post>

    constructor(private _pService: PostsService) {
        this.message = "Getting data from the server, please wait....";
    }

    ngOnInit() {
        this._pService.getAllPosts().subscribe((resData) => {
            this.posts = resData;
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }
}

// 1. HTTP call from Component
// import { Component, OnInit } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Post } from './models/post.model';

// @Component({
//     selector: 'root',
//     templateUrl: 'root.component.html'
// })

// export class RootComponent implements OnInit {
//     url: string;
//     message: string;
//     posts: Array<Post>

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Getting data from the server, please wait....";
//     }

//     ngOnInit() {
//         this.httpClient.get<Array<Post>>(this.url).subscribe((resData) => {
//             this.posts = resData;
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }
// }