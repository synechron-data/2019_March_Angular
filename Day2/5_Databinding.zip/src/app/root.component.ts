import { Component } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Data Binding</h1>
            </div>

            <div>
                <h2 class="text-success">Two Way Binding</h2>
                <h3>Message: {{message}}</h3>
                <!-- <input type="text" bindon-ngModel=message/>
                <input type="text" [(ngModel)]=message/>
                <input type="text" [(ngModel)]=message [ngModelOptions]="{updateOn: 'blur'}"/> -->

                <hr/>
                <input type="text" [(ngModel)]=city (change)=doUpdate(city) (blur)=doBlur()/>

                <input type="text" [(ngModel)]=city (input)=doUpdate(city)/>
                <h3>You are from : {{city}}</h3>
            </div>

            <div [hidden]=flag>
                <h2 class="text-success">Event Binding</h2>
                <h3>Message: {{message}}</h3>
                <button class="btn btn-info" on-click=doChange()>Click</button>
                <button class="btn btn-info" (click)=doChange()>Click</button>
            </div>

            <div [hidden]=flag>
                <h2 class="text-success">Property Binding</h2>
                <h3>Message: {{message}}</h3>
                <h3 innerHTML={{message}}>Message: </h3>
                <h3 bind-innerHTML=message>Message: </h3>
                <h3 [innerHTML]=message>Message: </h3>
                <input type="text" [value]=message>
            </div>
        </div>
    `
})
export class RootComponent {
    message: string;
    flag: boolean;

    constructor() {
        this.message = "Hello World";
        this.flag = true;
    }

    doChange() {
        this.message = new Date().toTimeString();
    }

    doUpdate(city: string) {
        // console.log("This is Change...");
        this.message = "Hi, you are from " + city;
    }

    doBlur(city: string) {
        // console.log("This is Blur...");
    }
}