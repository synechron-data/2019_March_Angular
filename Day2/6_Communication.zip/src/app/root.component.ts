import { Component } from "@angular/core";

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Communication</h1>
            </div>

            <!-- <h2>Selected: {{pname}}</h2>
            <list [pList]=personList (onSelection)="onSelect($event)"></list> -->

            <counter></counter>
        </div>
    `
})
export class RootComponent {
    personList: Array<string>;
    pname: string;

    constructor() {
        this.personList = ["Manish", "Abhijeet", "Abhishek", "Kedar", "Sumeet"];
    }

    onSelect(personName:string){
        this.pname = personName;
    }
}