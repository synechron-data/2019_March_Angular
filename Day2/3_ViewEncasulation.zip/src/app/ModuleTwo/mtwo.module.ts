import { NgModule } from '@angular/core';

import { CTwoComponent } from './ctwo.component';

@NgModule({
    exports: [CTwoComponent],
    declarations: [CTwoComponent],
})
export class CTwoModule { }
