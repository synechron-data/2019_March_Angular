import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { RootComponent } from "./root.component";
import { COneModule } from "./ModuleOne/mone.module";
import { CTwoModule } from "./ModuleTwo/mtwo.module";

@NgModule({
    imports: [BrowserModule, COneModule, CTwoModule],
    declarations: [RootComponent],
    bootstrap: [RootComponent]
})
export class RootModule { }